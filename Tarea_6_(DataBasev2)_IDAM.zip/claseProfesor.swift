class claseProfesor{
  var idProfesor: Int
  var nombre: String
  var apPaterno: String
  var apMaterno: String

  init(id_Profesor:Int, Nombre:String, ap_Paterno:String, ap_Materno:String){
    idProfesor = id_Profesor
    nombre = Nombre
    apPaterno = ap_Paterno
    apMaterno = ap_Materno
  }

  func consultaProfesores(){
    print("ID: \(idProfesor)\nProfesor: \(nombre) \(apPaterno) \(apMaterno)")
  }

  func mostrarEliminacionProfesor(){
    print("\nSe eliminó el profesor con el ID: \(idProfesor)")
  }
}

func agregarProfesor(){
  print("ID: ",terminator:"")
  var idProfesorS = readLine()!
  var idProfesor = Int(idProfesorS)!
  print("Nombre: ",terminator:"")
  var nombre = readLine()!
  print("Apellido Paterno: ",terminator:"")
  var apPaterno = readLine()!
  print("Apellido Materno: ",terminator:"")
  var apMaterno = readLine()!

  var profesor = claseProfesor(id_Profesor: idProfesor, Nombre: nombre, ap_Paterno: apPaterno, ap_Materno: apMaterno)

  listaProfesores.append(profesor)
}

func eliminarProfesor(){
  print("Introduce el ID del profesor que desea eliminar: ",terminator:"")
  var ID = readLine()!
  var IDInt = Int(ID)!
  var i : Int = 0

  var Encontrado : Bool = false

  for elemento in listaProfesores{
    if IDInt == elemento.idProfesor{
      listaProfesores.remove(at:i)
      print("\nEspere un momento... Eliminado\n")
      Encontrado = true
    } 
    i+=1
  }
  if Encontrado == false{
    print("\nNo se encontró el ID")
  }
  print("\nPresione cualquier tecla para regresar...")
}