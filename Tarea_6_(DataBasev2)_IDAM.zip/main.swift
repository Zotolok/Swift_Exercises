import Glibc

// Clase
class claseAlumno{
  // Parámetros
  var idAlumno:Int
  var nombre:String
  var apPaterno:String
  var apMaterno:String
  var semestre:Int

  // Constructor Alumno
  init(id_Alumno: Int, Nombre: String, ap_Paterno: String, ap_Materno: String, Semestre: Int){
    idAlumno = id_Alumno
    nombre = Nombre
    apPaterno = ap_Paterno
    apMaterno = ap_Materno
    semestre = Semestre
  }


  // Función de claseAlumno para consultar alumnos
  func consultaAlumnos(){
    print("ID: \(idAlumno)\nAlumno: \(nombre) \(apPaterno) \(apMaterno)\nSemestre: \(semestre)")
  }

  func mostrarEliminacionAlumno(){
    print("\nSe eliminó el alumno con el ID: \(idAlumno)")
  }
}

// Variables y arreglos
var listaAlumnos : Array<claseAlumno> = Array() // Arreglo de objetos
var listaProfesores : Array<claseProfesor> = Array() // Arreglo de objetos
var listaMateriasGeneral : [String] = []
var listaCalif : Array<claseCalifAlumno> = Array()
var nuevaListaCalif : Array<claseCalifAlumno> = Array()
var miOpcion : Int = 0

// Objetos
var alumno0 = claseAlumno(id_Alumno:2877240, Nombre:"Celic",ap_Paterno:"Hernández",ap_Materno:"Archundia",Semestre:4)

var profesor0 = claseProfesor(id_Profesor:3877240, Nombre:"Gabriel",ap_Paterno:"Hernández",ap_Materno:"Delgado")

listaMateriasGeneral.append("Español")

var materia0 = claseCalifAlumno(id_Alumno: 2877240, MateriaPe: "Español", Calif: 98)

listaAlumnos.append(alumno0)
listaProfesores.append(profesor0)
nuevaListaCalif.append(materia0)
//var alumno = claseAlumno()

// Llamar funciones
Inicio()

// Funciones
func MenuInicial(){
  Glibc.system("clear")

  print("Base de datos...\n")
  print("0. Salir.")
  print("1. Consultar")
  print("2. Agregar")
  print("3. Eliminar \n")
  print("Elige opción: ",terminator:"")
}

func Inicio(){
  MenuInicial()
  if var lsOpcion=readLine(){
    if var liOpcion=Int(lsOpcion){
      miOpcion=liOpcion

      switch miOpcion{
        case 0:
          print("\nHasta pronto... uwu")
          exit(1)
          break
        case 1:
          Glibc.system("clear")
          print("1. Consultar alumnos.")
          print("2. Consultar profesores.")
          print("3. Consultar materias.")
          print("4. Consultar calificaciones.")
          
          print("\nOpción: ",terminator:"")

          if var consultaOpcion = readLine(){
            if var consultaIntOpcion = Int(consultaOpcion){
              miOpcion = consultaIntOpcion

              switch miOpcion{
                case 1:
                  Glibc.system("clear")
                  if listaAlumnos.isEmpty == true{
                    print("La lista está vacía...")
                    print("\nPresione cualquier tecla para regresar al inicio...")
                    var _ = readLine()
                    Inicio()
                  } else{
                    var i : Int = 1
                    for alumno in listaAlumnos{
                    print("Alumno \(i):")
                    print(alumno.consultaAlumnos())
                    print("\n")
                    i+=1
                    }
                    print("\nPresione cualquier tecla para regresar...")
                    var _ = readLine()
                    Inicio()
                  }
                  
                  break

                case 2:
                  Glibc.system("clear")
                  if listaProfesores.isEmpty == true{
                    print("La lista está vacía...")
                    print("\nPresione cualquier tecla para regresar al inicio...")
                    var _ = readLine()
                    Inicio()
                  } else{
                    var i : Int = 1
                    for profesor in listaProfesores{
                    print("Profesor \(i):")
                    print(profesor.consultaProfesores())
                    print("\n")
                    i+=1
                    }
                    print("\nPresione cualquier tecla para regresar...")
                    var _ = readLine()
                    Inicio()
                  }
                  break

                case 3:
                  Glibc.system("clear")
                  print("Materias:\n")
                  var i: Int = 1
                  for materias in listaMateriasGeneral{
                    print("\(i). \(materias)")
                    i+=1
                  }
                  print("\nPresione cualquier tecla para ir al inicio...")
                    var _ = readLine()
                    Inicio()
                  
                  break

                case 4:
                  Glibc.system("clear")
                  if listaMateriasGeneral.isEmpty == true{
                    print("La lista está vacía...")
                    print("\nPresione cualquier tecla para regresar al inicio...")
                    var _ = readLine()
                    Inicio()
                  } else{
                    var i: Int=0
                    var i1 : Int = 1
                    for alumno in listaAlumnos{
                      print("Alumno \(i1) con ID: ",terminator: "")
                    print(alumno.idAlumno)
                    for calif in nuevaListaCalif{
                      if alumno.idAlumno == calif.idAlumno{ 
                        print(calif.consultaCalif())
                      }
                    }
                               
                      
                    i1+=1
                    }
                    print("\n\nPresione cualquier tecla para regresar...")
                    var _ = readLine()
                    Inicio()
                  }
                  
                  
                  break
                  
                default:
                  break
                  
              }
            }
          } else{
            print ("Opción inválida\n")
            print ("Oprime cualquier tecla para continuar.")
            var _ = readLine()
            Inicio()
          }
        
          break
          
        case 2:
          Glibc.system("clear")
          print("1. Agregar alumno.")
          print("2. Agregar profesor.")
          print("3. Agregar materias.")
          print("4. Agregar calificación.")

          print("\nOpción: ",terminator:"")

          if var agregarOpcion = readLine(){
            if var agregarIntOpcion = Int(agregarOpcion){
              miOpcion = agregarIntOpcion

              switch miOpcion{
                case 1:
                  Glibc.system("clear")
                  agregarAlumno()
                  print("\nPresione cualquier tecla para regresar...")
                  var _ = readLine()
                  Inicio()
                
                  break

                case 2:
                  Glibc.system("clear")
                  agregarProfesor()
                  print("\nPresione cualquier tela para regresar...")
                  var _ = readLine()
                  Inicio()
                  
                  break

                case 3:
                  agregarMateriasGenerales()
                  var _ = readLine()
                  Inicio()
                  break

                case 4:
                  Glibc.system("clear")
                  agregarCalifM()
                  print("\nPresione cualquier tecla para regresar al inicio...")
                  var _ = readLine()
                  Inicio()
                  break
                
                default:
                  break
                  
              }
            }
          } else{
            print ("Opción inválida\n")
            print ("Oprime cualquier tecla para continuar.")
            var _ = readLine()
            Inicio()
          }
          
          break
        
        case 3:
          Glibc.system("clear")
          print("1. Eliminar alumno.")
          print("2. ELiminar profesor.")
          print("3. Eliminar materia.")
          print("4. Eliminar calificación.")

          print("\nOpción: ",terminator:"")

          if var eliminarOpcion = readLine(){
            if var eliminarIntOpcion = Int(eliminarOpcion){
              miOpcion = eliminarIntOpcion

              switch miOpcion{
                case 1:
                  Glibc.system("clear")
                  if listaAlumnos.isEmpty == true{
                    print("La lista está vacía...")
                    print("\nPresione cualquier tecla para regresar al inicio...")
                    var _ = readLine()
                    Inicio()
                  } else{
                    eliminarAlumno()
                    var _ = readLine()
                    Inicio()
                  }
                  
                  break
                case 2:
                  Glibc.system("clear")
                  if listaProfesores.isEmpty == true{
                    print("La lista está vacía...")
                    print("\nPresione cualquier tecla para regresar al inicio...")
                    var _ = readLine()
                    Inicio()
                  } else{
                    eliminarProfesor()
                    var _ = readLine()
                    Inicio()
                  }
                  break

                case 3:
                  eliminarMateria()
                  var _ = readLine()
                  Inicio()
                  
                  break

                case 4:
                  Glibc.system("clear")
                  if nuevaListaCalif.isEmpty == true{
                    print("La lista está vacía...")
                    print("\nPresione cualquier tecla para regresar al inicio...")
                    var _ = readLine()
                    Inicio()
                  } else{
                    eliminarCalif()
                    var _ = readLine()
                    Inicio()
                  }
                  break
                
                default:
                  break
                  
              }
            }
          } else{
            print ("Opción inválida\n")
            print ("Oprime cualquier tecla para continuar.")
            var _ = readLine()
            Inicio()
          }
        
          break
        
        default:
          print ("Opción inválida\n")
          print("Oprime cualquier tecla para continuar.")
          var _ = readLine()
          Inicio()
          break
      }
    }
    else{
      print ("Opción inválida\n")
      print ("Oprime cualquier tecla para continuar.")
      var _ = readLine()
      Inicio()
    }
  }
}

// Función Agregar
func agregarAlumno(){
  print("ID: ",terminator:"")
  var id_AlumnoS = readLine()!
  var id_Alumno = Int(id_AlumnoS)!
  print("Nombre: ",terminator:"")
  var Nombre = readLine()!
  print("Apellido Paterno: ",terminator:"")
  var ap_Paterno = readLine()!
  print("Apellido Materno: ",terminator:"")
  var ap_Materno = readLine()!
  print("Semestre: ",terminator:"")
  var SemestreS = readLine()!
  var Semestre = Int(SemestreS)!

  var alumno = claseAlumno(id_Alumno: id_Alumno, Nombre: Nombre, ap_Paterno: ap_Paterno, ap_Materno: ap_Materno, Semestre: Semestre)
  
  listaAlumnos.append(alumno)
}

func eliminarAlumno(){
  print("Introduce el ID del alumno que desea eliminar: ",terminator:"")
  var ID = readLine()!
  var IDInt = Int(ID)!
  var i : Int = 0
  var Encontrado : Bool = false

  for elemento in listaAlumnos{
    if IDInt == elemento.idAlumno{
      listaAlumnos.remove(at:i)
      print("\nEspere un momento... Eliminado\n")
      Encontrado = true
    } 
    i+=1
  }
  if Encontrado == false{
    print("\nNo se encontró el ID")
  }
  print("\nPresione cualquier tecla para ir al inicio...")
}



