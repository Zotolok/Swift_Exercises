import Glibc

class claseCalifAlumno{
  var idAlumno: Int
  var materia: String
  var calificacion: Float

  init(id_Alumno: Int, MateriaPe: String ,Calif:Float){
    idAlumno = id_Alumno
    materia = MateriaPe
    calificacion = Calif
  }
  
  func consultaCalif(){
    print("\(materia): \(calificacion)")
  }
}

func agregarCalifM(){
  Glibc.system("clear")
  var Encontrado: Bool = false
  print("Agregar calificaciones:\n")
  print("Ingrese el ID del alumno: ",terminator:"")
  var ID = readLine()!
  var IDInt = Int(ID)!
  
  var i: Int=0

  for id in listaAlumnos{
    if IDInt == id.idAlumno{
      print("\nAlumno encontrado...\n")
      print("¿Qué materia será calificada?: ",terminator:"")
      var materiaF = readLine()!

      for calif in nuevaListaCalif{
        if calif.materia == materiaF && calif.calificacion != nil && calif.idAlumno == id.idAlumno {
          print("\nError, no puede agregar calificación a una materia previamente calificada. Elimine la calificación primero...\n\nPresiones cualquier tecla para ir al inicio\n")
          var _ = readLine()
          Inicio()
        }
      }

      for Materia in listaMateriasGeneral{
        if Materia == materiaF{
          print("Ingrese la calificación...\n")
          print("\(materiaF): ",terminator:"")
          var calificacion = readLine()!
          var calificacionFloat = Float(calificacion)!

          var calificacionMateria = claseCalifAlumno(id_Alumno: IDInt, MateriaPe: materiaF, Calif: calificacionFloat)
     nuevaListaCalif.append(calificacionMateria)  
          Encontrado = true
        }
      }
      if Encontrado == false{
        print("\nError, esa materia no existe...\nPresione cualquier tecla para ir al Inicio\n")
        var _ = readLine()
        Inicio()
        
      }
    }
  }
}

func eliminarCalif(){
  print("Introduce el ID del alumno para cambiar su calificación: ",terminator:"")
  var ID = readLine()!
  var IDInt = Int(ID)!
  var Encontrado: Bool = false
  var i: Int = 0

  for alumno in listaAlumnos{
    if IDInt == alumno.idAlumno{
      print("\nNombre de la materia: ",terminator:"")
      var materia = readLine()!
      for materias in listaMateriasGeneral{
        if materia == materias {
          for calif in nuevaListaCalif{
            if IDInt == calif.idAlumno{
              nuevaListaCalif.remove(at:i)
              Encontrado = true
            }
            i+=1
          }
        }
      }
      if Encontrado == false{
        print("\nError, materia no encontrada\n\nPresione cualquier tecla para volver al inicio...\n")
        var _ = readLine()
        Inicio()
      }
    }
  }
  if Encontrado == false{
    print("\nError, ID no encontrado\n\nPresione cualquier tecla para volver al inicio...\n")
    var _ = readLine()
    Inicio()
    }
    
  print("\nEspere un momento... Calificación borrada")
  print("\nPresione cualquier tecla para regresar al inicio...")
  var _ = readLine()
  Inicio()

}

/*
func agregarCalif(){
  Glibc.system("clear")
  var listaCalifFuncion : [Float] = []
  
  print("Ingrese las calificaciones.\n")
  print("ID del alumno: ",terminator:"")
  var ID = readLine()!
  var IDInt = Int(ID)!
  var i: Int=0
  var i2: Int = 1

  for elemento in listaAlumnos{
    if IDInt == elemento.idAlumno{
      for materias in listaMateriasGeneral{
        print("\(i2). \(materias): ",terminator:"")
        var calif = readLine()!
        var califF = Float(calif)!
        listaCalifFuncion.append(califF)
      } 
    } else{
      print("\nNo existe ese ID...\nPresione cualquier tecla para regresar al inicio...")
      var _ = readLine()
      Inicio()
    }  
  }
  var califMateriaAlumno = claseCalifAlumno(id_Alumno: IDInt, Calif: listaCalifFuncion)

  listaCalif.append(califMateriaAlumno)
}
*/