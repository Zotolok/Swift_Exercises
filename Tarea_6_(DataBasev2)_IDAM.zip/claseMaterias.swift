import Glibc

class claseMaterias{
  var materias: [String]

  init(Materias: [String]){
    materias = Materias
  }

  func consultaMaterias(){
    var listaMateriasParticular : [String] = []
    
    
  }
}

func agregarMateriasGenerales(){
  Glibc.system("clear")
  var Salir: Bool = false
  print("Materias de Alumnos (Para salir escriba 0)")
  repeat{
    print("Ingresar materia: ",terminator:"")
    var materia = readLine()!
    if materia == ""{
      print("\nIngrese una materia...")
      var _ = readLine()
      print("\nPresione cualquier botón para repetir la acción...")
      agregarMateriasGenerales()
    
    } else if materia == "0"{
      Inicio()
    }
    
    listaMateriasGeneral.append(materia)
    
  } while Salir == false
}

func eliminarMateria(){
  Glibc.system("clear")
  var i: Int = 0
  var Encontrado: Bool = false
  
  print("Materia a eliminar: ",terminator:"")
  var materia = readLine()!
  for Melemento in listaMateriasGeneral{
    if materia == Melemento{
      listaMateriasGeneral.remove(at:i) 
      Encontrado = true
    }
    i+=1
  }
  if Encontrado == false{
    print("\nNo se encontró la materia")
  }
  print("\nPresione cualquier tecla para ir al inicio...")
  Inicio()
}

// Clase pendiente
func agregarMateriasParticulares(){
  Glibc.system("clear")
  print("Ingrese el ID del alumno: ",terminator:"")
  var ID = readLine()!
  var IDInt = Int(ID)!
  var i : Int = 1
  var i2 : Int = 0

  var Encontrado : Bool = false
  var Salir : Bool = false

  for elemento in listaAlumnos{
    if IDInt == elemento.idAlumno{
      
      print("\nAgregue las materias:\n")
      /*
      repeat {
        print("Materia: ",terminator:"")
        var materia = readLine()!
        var materiasAlumno = claseMaterias(Materias: materia)
        
        
      } while
      */
    }
  }
}